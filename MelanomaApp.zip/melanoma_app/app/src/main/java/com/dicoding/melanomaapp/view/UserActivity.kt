package com.dicoding.melanomaapp.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.melanomaapp.R

class UserActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)
    }

}