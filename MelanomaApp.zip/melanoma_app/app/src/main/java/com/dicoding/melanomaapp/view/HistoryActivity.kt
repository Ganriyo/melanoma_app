package com.dicoding.melanomaapp.view

import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity(){
}