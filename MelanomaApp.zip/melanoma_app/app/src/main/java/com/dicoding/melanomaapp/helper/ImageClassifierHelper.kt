package com.dicoding.melanomaapp.helper

class ImageClassifierHelper {
}